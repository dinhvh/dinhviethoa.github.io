#ifndef ETPAN_ACCOUNT_TYPES_H

#define ETPAN_ACCOUNT_TYPES_H

#include <libetpan/libetpan.h>
#include "etpan-storage-types.h"
#include "etpan-sender-types.h"
#include "etpan-outbox-types.h"

struct etpan_account {
  int ref_count;
  char * id;
  
  char * display_name;
  char * mail;
  
  struct etpan_storage * storage;
  carray * outbox_list;
  
  /* trash, outbox, draft, sent */
  chash * special_folder_list; /* XXX - must be set by storage and folder */
  
  int stopped;
  int stop_remaining;
  void * stop_cb_data;
  void (* stop_callback)(void *);
};

#endif
