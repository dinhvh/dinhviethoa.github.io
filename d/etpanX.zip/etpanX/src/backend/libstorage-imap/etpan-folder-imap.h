#ifndef ETPAN_FOLDER_IMAP_H

#define ETPAN_FOLDER_IMAP_H

struct etpan_folder * etpan_folder_imap_new(void);

void etpan_folder_imap_set_noinferiors(struct etpan_folder * folder,
    int noinferiors);
int etpan_folder_imap_get_noinferiors(struct etpan_folder * folder);

void etpan_folder_imap_set_separator(struct etpan_folder * folder,
    char separator);
char etpan_folder_imap_get_separator(struct etpan_folder * folder);

#endif
