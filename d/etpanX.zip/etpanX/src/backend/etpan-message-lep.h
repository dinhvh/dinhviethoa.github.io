#ifndef ETPAN_MESSAGE_LEP_H

#define ETPAN_MESSAGE_LEP_H

#include <libetpan/libetpan.h>

#include "etpan-message.h"

struct etpan_message * etpan_message_lep_new(void);

void etpan_message_lep_set_msg(struct etpan_message * msg,
    struct mailmessage * ep_msg);

struct mailmessage * etpan_message_lep_get_msg(struct etpan_message * msg);

#endif
