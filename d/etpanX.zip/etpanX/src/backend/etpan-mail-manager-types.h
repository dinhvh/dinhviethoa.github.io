#ifndef ETPAN_MAIL_MANAGER_TYPES_H

#define ETPAN_MAIL_MANAGER_TYPES_H

#define ETPAN_MAIL_MANAGER_MSG_LIST_UPDATED_SIGNAL \
   "org.etpan.mail-manager.msg-list-updated"

#define ETPAN_MAIL_MANAGER_STATUS_UPDATED_SIGNAL \
   "org.etpan.mail-manager.status-updated"

#define ETPAN_MAIL_MANAGER_INDEXER_UPDATED_SIGNAL \
   "org.etpan.mail-manager.indexer-updated"

#define ETPAN_MAIL_MANAGER_FOLDER_LIST_UPDATED_SIGNAL \
   "org.etpan.mail-manager.folder-list-updated"

/*
#define ETPAN_MAIL_MANAGER_TASK_DONE_SIGNAL \
   "org.etpan.mail-manager.task-done"
*/

#define ETPAN_MAIL_MANAGER_SCHEDULE_SIGNAL \
   "org.etpan.mail-manager.schedule"



#define ETPAN_MAIL_MANAGER_COPY_MSG_FINISHED_SIGNAL \
   "org.etpan.mail-manager.copy-msg-finished"

#define ETPAN_MAIL_MANAGER_DELETE_MSG_FINISHED_SIGNAL \
   "org.etpan.mail-manager.delete-msg-finished"

#define ETPAN_MAIL_MANAGER_COPY_FOLDER_FINISHED_SIGNAL \
   "org.etpan.mail-manager.copy-folder-finished"

struct etpan_mail_manager {
  int stop;
  void (* stop_callback)(void *);
  void * stop_cb_data;
  chash * storage_to_state;
  struct etpan_error * delete_msg_error;
  carray * delete_msg_op_list;
  struct etpan_error * copy_msg_error;
  carray * copy_msg_op_list;
  struct etpan_error * copy_folder_error;
  carray * copy_folder_op_list;
};

#endif
