#ifndef ETPAN_SQLDB_TYPES_H

#define ETPAN_SQLDB_TYPES_H

#include <sqlite3.h>
#include <libetpan/libetpan.h>
#include <pthread.h>

struct etpan_sqldb {
  char * filename;
  sqlite3 * db;
  sqlite3_stmt ** get_statement;
  sqlite3_stmt ** set_statement;
  sqlite3_stmt ** update_statement;
  sqlite3_stmt * delete_statement;
  sqlite3_stmt * get_keys_statement;
  carray * column_list;
  chash * name_to_index;
  pthread_mutex_t lock;
};

#endif
