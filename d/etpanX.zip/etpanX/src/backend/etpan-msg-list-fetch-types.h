#ifndef ETPAN_MSG_LIST_FETCH_TYPES_H

#define ETPAN_MSG_LIST_FETCH_TYPES_H

#include "etpan-thread-manager-types.h"
#include "etpan-folder-types.h"
#include "etpan-error-types.h"
#include "etpan-folder-filter-types.h"

/* notify this so that the view can remove the message
   that are no more available */
#define ETPAN_MSG_LIST_FETCH_FINISHED_WITH_LOST_SIGNAL \
    "org.etpan.msg-list-fetch.finished-with-lost"

#define ETPAN_MSG_LIST_FETCH_FINISHED_SIGNAL \
    "org.etpan.msg-list-fetch.finished"

struct etpan_msg_list_fetch {
  int ref_count;
  struct etpan_folder * folder;
  struct etpan_folder_filter * filter;
  struct etpan_thread_op * op;
  struct etpan_error * error;
};

#endif
