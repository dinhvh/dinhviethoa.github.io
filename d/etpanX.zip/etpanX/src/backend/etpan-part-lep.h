#ifndef ETPAN_PART_LEP_H

#define ETPAN_PART_LEP_H

#include "etpan-part.h"
#include <libetpan/libetpan.h>

struct etpan_part * etpan_part_lep_new(void);

void etpan_part_lep_set_mime(struct etpan_part * part,
    struct mailmime * ep_mime);

struct mailmime * etpan_part_lep_get_mime(struct etpan_part * part);

#endif
