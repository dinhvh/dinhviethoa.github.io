#ifndef ETPAN_MSG_LIST_ITERATOR_H

#define ETPAN_MSG_LIST_ITERATOR_H

#include "etpan-msg-list-iterator-types.h"

struct etpan_msg_list_iterator * etpan_msg_list_iterator_new(void);

void etpan_msg_list_iterator_free(struct etpan_msg_list_iterator * iterator);

void etpan_msg_list_iterator_set_msg_list(struct etpan_msg_list_iterator * iterator, chash * msg_list);

void etpan_msg_list_iterator_set_function(struct etpan_msg_list_iterator * iterator, void (* function)(struct etpan_message *, void *, void (* callback)(int iterate_continue, void *), void *), void * function_data);

void etpan_msg_list_iterator_run(struct etpan_msg_list_iterator * iterator,
    void (* step_callback)(void *),
    void (* callback)(void *), void * user_data);

#endif
