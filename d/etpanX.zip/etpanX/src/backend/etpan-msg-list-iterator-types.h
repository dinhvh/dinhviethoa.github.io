#ifndef ETPAN_MSG_LIST_ITERATOR_TYPES_H

#define ETPAN_MSG_LIST_ITERATOR_TYPES_H

#include <libetpan/libetpan.h>

#include "etpan-message-types.h"

struct etpan_msg_list_iterator {
  struct etpan_folder * folder;
  unsigned int current_msg_index;
  carray * msg_list;
  
  void (* iterator_function)(struct etpan_message *, void *, void (* callback)(int iterate_continue, void *), void *);
  void * function_data;
  
  void (* step_callback)(void * cb_data);
  void (* callback)(void * cb_data);
  void * cb_data;
};

#endif
