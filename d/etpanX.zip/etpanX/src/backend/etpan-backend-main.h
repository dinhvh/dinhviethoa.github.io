#ifndef ETPAN_BACKEND_MAIN_H

#define ETPAN_BACKEND_MAIN_H

#include "etpan-error-types.h"

struct etpan_error * etpan_backend_init(void);
void etpan_backend_setup(void);

void etpan_backend_stop(void (* callback)(void * cb_data), void * cb_data);
void etpan_backend_unsetup(void);

void etpan_backend_done(void);

#endif
