#ifndef ETPAN_FILTER_ACTION_TYPES_H

#define ETPAN_FILTER_ACTION_TYPES_H

#include "etpan-message-types.h"
#include "etpan-filter-types.h"

struct etpan_filter_action {
  struct etpan_filter_action_description * description;
  carray * param_list;
};

struct etpan_filter_action_description {
  char * name;
  void (* run)(struct etpan_filter_action * action,
      struct etpan_filter_state * filter_state,
      struct etpan_message * msg,
      void (* callback)(int stop, void * cb_data), void * data);
};

#endif
