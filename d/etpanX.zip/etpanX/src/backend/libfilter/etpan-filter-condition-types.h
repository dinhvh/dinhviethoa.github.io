#ifndef ETPAN_FILTER_CONDITION_TYPES_H

#define ETPAN_FILTER_CONDITION_TYPES_H

#include "etpan-message-types.h"

struct etpan_filter_condition {
  struct etpan_filter_condition_description * description;
  carray * param_list;
  carray * children;
};

struct etpan_filter_condition_description {
  char * name;
  void (* evaluate)(struct etpan_filter_condition * condition,
      struct etpan_message * msg,
      void (* callback)(int result, void * cb_data), void * data);
};

#endif
