#ifndef ETPAN_FOLDER_FILTER_TYPES_H

#define ETPAN_FOLDER_FILTER_TYPES_H

#include "etpan-filter-types.h"
#include "etpan-msg-list-iterator-types.h"
#include "etpan-folder-types.h"
#include "etpan-sqldb-types.h"

struct etpan_folder_filter {
  int ref_count;
  struct etpan_folder * folder;
  struct etpan_filter_config * filter_config;
  struct etpan_filter_config * filter_config_copy;
  struct etpan_msg_list_iterator * iterator;
  void (* filter_one_callback)(int iterate_continue, void *);
  void * filter_one_cb_data;
  struct etpan_filter_state * filter_state;
  int cancelled;
  struct etpan_sqldb * filtered_db;
  struct etpan_message * msg;
  void (* step_callback_wrapped)(void *);
  void (* callback_wrapped)(void *);
  chash * pending_filtered_db;
  void * cb_data_wrapped;
  int running;
  char * path;
  int pending;
};

struct etpan_folder_filter_filtered_msg_list_result {
  chash * msg_hash;
};

#endif
