#ifndef ETPAN_FILTER_CONFIG_TYPES_H

#define ETPAN_FILTER_CONFIG_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_filter_config {
  carray * filter_list;
};

#endif
