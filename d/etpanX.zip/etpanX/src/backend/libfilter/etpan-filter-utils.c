#include "etpan-filter-utils.h"

#include <string.h>
#include <stdlib.h>

#include "etpan-log.h"

char * etpan_filter_unquote_string(char * str)
{
  char * result;
  char * p_result;
  char * p;
  size_t len;
  
  len = strlen(str);
  result = malloc(len + 1);
  if (result == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  p_result = result;
  p = str;
  while (* p != '\0') {
    
    if (* p == '\\') {
      p ++;
      
      if (* p == '\0')
        break;
      
      * p_result = * p;
      p_result ++;
    }
    else {
      * p_result = * p;
      p_result ++;
    }
    
    p ++;
  }
  
  * p_result = '\0';
  
  return result;
}

