#ifndef ETPAN_FILTER_PARSER_GLUE_H

#define ETPAN_FILTER_PARSER_GLUE_H

#include "etpan-filter-config-types.h"

int etpan_filter_parser_parse_file(struct etpan_filter_config * config,
    char * filename);

#endif
