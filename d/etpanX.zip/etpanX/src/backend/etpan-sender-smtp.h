#ifndef ETPAN_SENDER_SMTP_H

#define ETPAN_SENDER_SMTP_H

struct etpan_sender * etpan_sender_smtp_new(void);

void etpan_sender_smtp_set_hostname(struct etpan_sender * sender,
    char * hostname);

char * etpan_sender_smtp_get_hostname(struct etpan_sender * sender);

void etpan_sender_smtp_set_port(struct etpan_sender * sender, int port);

int etpan_sender_smtp_get_port(struct etpan_sender * sender);

void etpan_sender_smtp_set_connection_type(struct etpan_sender * sender,
    int connection_type);

int etpan_sender_smtp_get_connection_type(struct etpan_sender * sender);

void etpan_sender_smtp_set_auth_type(struct etpan_sender * sender,
    int auth_type);

int etpan_sender_smtp_get_auth_type(struct etpan_sender * sender);

void etpan_sender_smtp_set_username(struct etpan_sender * sender,
    char * username);

char * etpan_sender_smtp_get_username(struct etpan_sender * sender);

void etpan_sender_smtp_set_password(struct etpan_sender * sender,
    char * password);

char * etpan_sender_smtp_get_password(struct etpan_sender * sender);

#endif
