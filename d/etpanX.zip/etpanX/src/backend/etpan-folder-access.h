#ifndef ETPAN_FOLDER_ACCESS_H

#define ETPAN_FOLDER_ACCESS_H

#include "etpan-folder-access-types.h"
#include <libetpan/libetpan.h>

/* init */

struct etpan_folder_access *  etpan_folder_access_new(void);

void etpan_folder_access_free(struct etpan_folder_access * access);

/* clean up */

void etpan_folder_access_clear(struct etpan_folder_access * access);

/* get info */

struct mailfolder *
etpan_folder_access_get_folder(struct etpan_folder_access * access,
    char * identifier);

struct mailstorage *
etpan_folder_access_get_storage(struct etpan_folder_access * access,
    char * identifier);

#endif
