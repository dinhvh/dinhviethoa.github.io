#ifndef ETPAN_FOLDER_VIEW_TYPES_H

#define ETPAN_FOLDER_VIEW_TYPES_H

#include "etpan-msg-list-view-types.h"

#define ETPAN_FOLDER_VIEW_SEARCH_UPDATED_RESULT \
  "org.etpan.folder-viewer.search-updated-result"

#define ETPAN_FOLDER_VIEW_SEARCH_FINISHED \
  "org.etpan.folder-viewer.search-finished"

struct etpan_folder_view {
  carray * folder_list;
  chash * folder_for_orphans;
  struct etpan_msg_list_view * msg_list_view;
  
  int has_message_list;

  int has_filter;
  
  int searching;
  chash * message_list;
};

#endif
