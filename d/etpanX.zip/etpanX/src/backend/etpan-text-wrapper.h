#ifndef ETPAN_TEXT_WRAPPER_H

#define ETPAN_TEXT_WRAPPER_H

#include <sys/types.h>

void etpan_wrap_text(char * input, size_t input_size,
    char ** p_output, size_t * p_output_size, int columns);

void etpan_unwrap_text(char * input, size_t input_size,
    char ** p_output, size_t * p_output_size);

#endif
