#ifndef ETPAN_BOOKMARK_TYPES_H

#define ETPAN_BOOKMARK_TYPES_H

#include <libetpan/libetpan.h>

/* TODO : extend to have same kind of layout as in a browser */

struct etpan_bookmark {
  char * display_name;
  char * storage;
  char * location;
};

struct etpan_bookmark_manager {
  carray * bookmark_list;
};

#endif
