#ifndef ETPAN_STORAGE_FOLDER_ORDER_TYPES_H

#define ETPAN_STORAGE_FOLDER_ORDER_TYPES_H

#include <libetpan/libetpan.h>

#include "etpan-folder-tree-types.h"
#include "etpan-storage-types.h"
#include "etpan-folder-types.h"

#define ETPAN_STORAGE_FOLDER_ORDER_CHANGED \
  "org.etpan.storage-folder-order.changed"

struct etpan_storage_folder_order {
  char * path;
  int loaded;
  struct etpan_folder_tree * tree ;
  carray * folder_order;
  chash * folder_hash;
  struct etpan_storage * storage;
};

#endif
