#ifndef ETPAN_FOLDER_DELETE_H

#define ETPAN_FOLDER_DELETE_H

#include "etpan-folder-delete-types.h"

struct etpan_folder_delete * etpan_folder_delete_new(void);

void etpan_folder_delete_ref(struct etpan_folder_delete * folder_delete);
void etpan_folder_delete_unref(struct etpan_folder_delete * folder_delete);

void etpan_folder_delete_set_folder(struct etpan_folder_delete * folder_delete,
    struct etpan_folder * folder);
struct etpan_folder *
etpan_folder_delete_get_folder(struct etpan_folder_delete * folder_delete);

void etpan_folder_delete_setup(struct etpan_folder_delete * folder_delete);

void etpan_folder_delete_run(struct etpan_folder_delete * folder_delete);
void etpan_folder_delete_cancel(struct etpan_folder_delete * folder_delete);

struct etpan_error *
etpan_folder_delete_get_error(struct etpan_folder_delete * folder_delete);

#endif
