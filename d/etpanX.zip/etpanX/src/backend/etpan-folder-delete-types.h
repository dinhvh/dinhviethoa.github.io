#ifndef ETPAN_FOLDER_DELETE_TYPES_H

#define ETPAN_FOLDER_DELETE_TYPES_H

#include "etpan-folder-types.h"
#include "etpan-storage-types.h"
#include "etpan-thread-manager-types.h"
#include "etpan-error-types.h"

#define ETPAN_FOLDER_DELETE_FINISHED_SIGNAL \
  "org.etpan.folder-delete.finished"

struct etpan_folder_delete {
  int ref_count;
  struct etpan_folder * folder;
  struct etpan_thread_op * op;
  struct etpan_folder_delete * subfolder_delete;
  carray * foldertab;
  unsigned int next_folder;
  int state;
  struct etpan_error * error;
  carray * error_list;
};

#endif
