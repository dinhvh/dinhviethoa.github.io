#ifndef ETPAN_MESSAGE_DELETE_TYPES_H

#define ETPAN_MESSAGE_DELETE_TYPES_H

#define ETPAN_MESSAGE_DELETE_FINISHED_SIGNAL \
  "org.etpan.message-delete.finished"

#include <libetpan/libetpan.h>

#include "etpan-message-copy-local-types.h"
#include "etpan-error-types.h"

struct etpan_message_delete {
  int ref_count;
  struct etpan_message_copy_local * msg_copy_local;
  struct etpan_error * error;
};

#endif
