#ifndef ETPAN_FOLDER_PRIVATE_H

#define ETPAN_FOLDER_PRIVATE_H

#include "etpan-folder-types.h"

/* _nt like "not threaded" */
struct etpan_error * etpan_folder_connect_nt(struct etpan_folder * folder) WARN_UNUSED_RESULT;
void etpan_folder_disconnect_nt(struct etpan_folder * folder);

#endif
