#ifndef ETPAN_INDEXER_TYPES_H

#define ETPAN_INDEXER_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#include <pthread.h>

struct etpan_indexer {
  int type;
  char * filename;
  void * data;
  pthread_mutex_t lock;
  int state;
  int ref_count;
  int locked;
};

#ifdef __cplusplus
}
#endif

#endif
