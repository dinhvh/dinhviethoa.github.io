#ifndef ETPAN_MESSAGE_TREE_LEP_TYPES_H

#define ETPAN_MESSAGE_TREE_LEP_TYPES_H

#include <libetpan/libetpan.h>
#include "etpan-message-types.h"

struct etpan_message_tree {
  struct etpan_message_tree * parent;
  struct etpan_message * msg;
  carray * children;
};

#endif
