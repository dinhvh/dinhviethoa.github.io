#ifndef ETPAN_FOLDER_CREATE_TYPES_H

#define ETPAN_FOLDER_CREATE_TYPES_H

#include "etpan-folder-types.h"
#include "etpan-storage-types.h"
#include "etpan-thread-manager-types.h"

#define ETPAN_FOLDER_CREATE_FINISHED_SIGNAL \
  "org.etpan.folder-create.finished"

struct etpan_folder_create {
  int ref_count;
  char * name;
  struct etpan_folder * parent_folder;
  struct etpan_storage * storage;
  char * location;
  struct etpan_error * error;
  struct etpan_thread_op * op;
  int state;
  struct etpan_folder * created_folder;
};

#endif
