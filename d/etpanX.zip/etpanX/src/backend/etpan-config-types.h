#ifndef ETPAN_CONFIG_TYPES_H

#define ETPAN_CONFIG_TYPES_H

#define ETPAN_ACCOUNT_FILE ".etpanX/account" 
#define ETPAN_ABOOK_FILE ".etpanX/abook" 

#define ETPAN_BOOKMARK_FILE ".etpanX/bookmark" 
#define ETPAN_TMP_DIR ".etpanX/tmp" 
#define ETPAN_MBOX_CACHE_FILE "mbox-cache"
#define ETPAN_SMIME_CA_DIR ".etpanX/smime/CA"
#define ETPAN_SMIME_CERT_DIR ".etpanX/smime/cert"
#define ETPAN_SMIME_PRIVATE_DIR ".etpanX/smime/private"
#define ETPAN_COLOR_FILE ".etpanX/color" 
#define ETPAN_GLOBAL_CONFIG_FILE ".etpanX/config" 
#define ETPAN_UI_CONFIG ".etpanX/gtk-ui-config"
#define ETPAN_FILTER_CONFIG_FILE ".etpanX/filter"

#define ETPAN_CACHE_DIR ".etpanX/cache"

#define ETPAN_ACCOUNT_DIR ".etpanX/account-data"

#define ETPAN_LOG_DIR ".etpanX/log"

#endif
