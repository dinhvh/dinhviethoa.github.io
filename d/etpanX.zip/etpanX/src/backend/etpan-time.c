#include "etpan-time.h"

#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

double etpan_get_time(void)
{
  struct timeval val;
  
  gettimeofday(&val, NULL);
  
  return (double) val.tv_sec + (double) val.tv_usec / (double) 1000000;
}
