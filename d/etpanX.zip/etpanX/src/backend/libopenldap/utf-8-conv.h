#ifndef UTF_8_CONV_H

#define UTF_8_CONV_H

#include <wchar.h>

#ifdef __cplusplus
extern "C" {
#endif

int
etpan_utf8_to_wc ( wchar_t *wchar, const char *utf8char );

int
etpan_utf8s_to_wcs ( wchar_t *wcstr, const char *utf8str, size_t count );

int
etpan_wc_to_utf8 ( char *utf8char, wchar_t wchar, size_t count );

int
etpan_wcs_to_utf8s ( char *utf8str, const wchar_t *wcstr, size_t count );

#ifdef __cplusplus
}
#endif

#endif
