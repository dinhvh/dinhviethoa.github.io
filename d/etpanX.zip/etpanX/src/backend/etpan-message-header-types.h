#ifndef ETPAN_MESSAGE_HEADER_TYPES_H

#define ETPAN_MESSAGE_HEADER_TYPES_H

struct etpan_message_header {
  carray * from; /* array of etpan_address */
  carray * replyto; /* array of etpan_address */
  carray * to; /* array of etpan_address */
  carray * cc; /* array of etpan_address */
  carray * bcc; /* array of etpan_address */
  carray * resent_from; /* array of etpan_address */
  carray * resent_to; /* array of etpan_address */
  carray * resent_cc; /* array of etpan_address */
  carray * resent_bcc; /* array of etpan_address */
  char * subject;
  char * newsgroups;
  time_t date;
  char * msgid;
  time_t resent_date;
  char * resent_msgid;
  carray * references;
  carray * inreplyto;
  struct etpan_address * listpost;
};

struct etpan_unparsed_header_item {
  char * name;
  char * value;
};

#endif
