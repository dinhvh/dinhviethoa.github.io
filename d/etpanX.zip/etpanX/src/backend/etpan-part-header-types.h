#ifndef ETPAN_PART_HEADER_TYPES_H

#define ETPAN_PART_HEADER_TYPES_H

enum {
  ETPAN_PART_MIME_ENCODING_BASE64,
  ETPAN_PART_MIME_ENCODING_QUOTEDPRINTABLE,
  ETPAN_PART_MIME_ENCODING_OTHER,
};

struct etpan_part_header {
  char * content_type;
  char * filename;
  int mime_encoding;
  char * charset_encoding;
};

#endif
