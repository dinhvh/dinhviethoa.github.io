#ifndef ETPAN_TC_H

#define ETPAN_TC_H

#include "tcconf.h"
#include "tcalloc.h"
#include "tcdirent.h"

char * etpan_quote_string(char * value);

#endif
