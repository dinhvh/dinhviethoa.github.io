#ifndef ETPAN_ACCOUNT_CONFIG_H

#define ETPAN_ACCOUNT_CONFIG_H

#include "etpan-account-manager-types.h"
#include "etpan-error-types.h"

struct etpan_error *
etpan_account_config_read(struct etpan_account_manager * manager,
    char * filename) WARN_UNUSED_RESULT;

struct etpan_error *
etpan_account_config_read_default(void) WARN_UNUSED_RESULT;

struct etpan_error *
etpan_account_config_save(struct etpan_account_manager * manager,
    char * filename) WARN_UNUSED_RESULT;

struct etpan_error *
etpan_account_config_save_default(void) WARN_UNUSED_RESULT;

#endif
