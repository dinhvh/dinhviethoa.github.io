#ifndef ETPAN_STORAGE_MBOX_PRIVATE_H

#define ETPAN_STORAGE_MBOX_PRIVATE_H

#include "etpan-storage-types.h"

char * etpan_storage_mbox_get_threaded_path(struct etpan_storage *
    storage);

#endif
