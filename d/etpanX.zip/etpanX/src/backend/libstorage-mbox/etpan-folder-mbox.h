#ifndef ETPAN_FOLDER_MBOX_H

#define ETPAN_FOLDER_MBOX_H

struct etpan_folder * etpan_folder_mbox_new(void);

#endif
