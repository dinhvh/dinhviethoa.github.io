#ifndef ETPAN_STORAGE_MBOX_H

#define ETPAN_STORAGE_MBOX_H

#include "etpan-storage-types.h"

struct etpan_storage * etpan_storage_mbox_new(void);

void etpan_storage_mbox_set_path(struct etpan_storage * storage, char * path);

char * etpan_storage_mbox_get_path(struct etpan_storage * storage);

#endif
