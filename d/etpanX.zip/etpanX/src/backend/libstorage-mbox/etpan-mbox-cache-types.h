#ifndef ETPAN_MBOX_CACHE_TYPES_H

#define ETPAN_MBOX_CACHE_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_mbox_cache {
  char * filename;
  chash * db;
};

#endif
