#ifndef ETPAN_TIME_H

#define ETPAN_TIME_H

double etpan_get_time(void);

#endif
