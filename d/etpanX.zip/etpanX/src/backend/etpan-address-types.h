#ifndef ETPAN_ADDRESS_TYPES_H

#define ETPAN_ADDRESS_TYPES_H

struct etpan_address {
  char * display_name;
  char * address;
};

#endif
