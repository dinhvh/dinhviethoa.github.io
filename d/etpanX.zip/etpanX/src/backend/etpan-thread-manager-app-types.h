#ifndef ETPAN_THREAD_MANAGER_APP_TYPES_H

#define ETPAN_THREAD_MANAGER_APP_TYPES_H

#include <libetpan/libetpan.h>

#include "etpan-thread-manager-types.h"

struct etpan_thread_manager_app {   
  struct etpan_thread_manager * manager;
  
  /* storage thread */
  chash * storage_hash;
  /* sender thread */
  chash * sender_hash;
  /* address book thread */
  chash * abook_hash;
  
  int stop_called;
  void (* stop_callback)(void *);
  void * stop_cb_data;
};

#endif
