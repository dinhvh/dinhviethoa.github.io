#ifndef ETPAN_ACCOUNT_MANAGER_TYPES

#define ETPAN_ACCOUNT_MANAGER_TYPES

#include <libetpan/libetpan.h>

#define ETPAN_ACCOUNT_MANAGER_MODIFICATION_SIGNAL \
  "org.etpan.account-manager.modification"

struct etpan_account_manager {
  char * path;
  
  chash * account_hash;
  carray * ordered_list;
  
  int stop_remaining;
  void * stop_cb_data;
  void (* stop_callback)(void *);
};

#endif
