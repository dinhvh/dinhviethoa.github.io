#ifndef ETPAN_FOLDER_ACCESS_TYPES_H

#define ETPAN_FOLDER_ACCESS_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_folder_access {
  chash * folder_hash;
  chash * storage_hash;
};

#endif
