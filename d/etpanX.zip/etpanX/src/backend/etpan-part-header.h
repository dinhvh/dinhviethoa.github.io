#ifndef ETPAN_PART_HEADER_H

#include "etpan-part-header-types.h"

struct etpan_part_header * etpan_part_header_new(void);

void etpan_part_header_free(struct etpan_part_header * header);

void etpan_part_header_set_content_type(struct etpan_part_header * header,
    char * content_type);
char * etpan_part_header_get_content_type(struct etpan_part_header * header);

void etpan_part_header_set_filename(struct etpan_part_header * header,
    char * filename);
char * etpan_part_header_get_filename(struct etpan_part_header * header);

void etpan_part_header_set_mime_encoding(struct etpan_part_header * header,
    int mime_encoding);
int etpan_part_header_get_mime_encoding(struct etpan_part_header * header);

void etpan_part_header_set_charset_encoding(struct etpan_part_header * header,
    char * description);
char *
etpan_part_header_get_charset_encoding(struct etpan_part_header * header);

#endif
