#include "etpan-thread-manager.h"

#include <stdlib.h>
#include <pthread.h>
#include <libetpan/mailsem.h>
#include <semaphore.h>
#include <unistd.h>

#include "etpan-log.h"
#include "etpan-error.h"

#define POOL_UNBOUND_MAX 4

#define POOL_INIT_SIZE 8
#define OP_INIT_SIZE 8

enum {
  TERMINATE_STATE_NONE,
  TERMINATE_STATE_REQUESTED,
  TERMINATE_STATE_DONE,
};

struct etpan_thread_manager * etpan_thread_manager_new(void)
{
  struct etpan_thread_manager * manager;
  int r;
  
  manager = malloc(sizeof(* manager));
  if (manager == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  manager->thread_pool = carray_new(POOL_INIT_SIZE);
  if (manager->thread_pool == NULL)
    ETPAN_LOG_MEMORY_ERROR;

  manager->thread_pending = carray_new(POOL_INIT_SIZE);
  if (manager->thread_pending == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  r = pthread_mutex_init(&manager->main_thread_lock, NULL);
  if (r != 0) {
    ETPAN_LOG("failed to create mutex (manager)");
    etpan_crash();
  }
  
  manager->main_thread_list = carray_new(16);
  if (manager->main_thread_list == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  manager->can_create_thread = 1;
  manager->unbound_count = 0;
  
  r = pipe(manager->notify_fds);
  if (r < 0)
    ETPAN_LOG_MEMORY_ERROR;
  
  return manager;
}

void etpan_thread_manager_free(struct etpan_thread_manager * manager)
{
  close(manager->notify_fds[1]);
  close(manager->notify_fds[0]);
  carray_free(manager->main_thread_list);
  pthread_mutex_destroy(&manager->main_thread_lock);
  carray_free(manager->thread_pending);
  carray_free(manager->thread_pool);
  free(manager);
}

struct etpan_thread * etpan_thread_new(void)
{
  struct etpan_thread * thread;
  int r;
  
  thread = malloc(sizeof(* thread));
  if (thread == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  r = pthread_mutex_init(&thread->lock, NULL);
  if (r != 0)
    ETPAN_LOG_MEMORY_ERROR;

  thread->op_list = carray_new(OP_INIT_SIZE);
  if (thread->op_list == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  thread->op_done_list = carray_new(OP_INIT_SIZE);
  if (thread->op_done_list == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  thread->start_sem = mailsem_new();
  if (thread->start_sem == NULL) {
    ETPAN_LOG("failed to create semaphore (start)");
    etpan_crash();
  }
  
  thread->stop_sem = mailsem_new();
  if (thread->stop_sem == NULL) {
    ETPAN_LOG("failed to create semaphore (step)");
    etpan_crash();
  }
  
  thread->op_sem = mailsem_new();
  if (thread->op_sem == NULL) {
    ETPAN_LOG("failed to create semaphore (op)");
    etpan_crash();
  }
  
  thread->manager = NULL;
  thread->bound_count = 0;
  thread->terminate_state = TERMINATE_STATE_NONE;
  
  return thread;
}

void etpan_thread_free(struct etpan_thread * thread)
{
  mailsem_free(thread->op_sem);
  mailsem_free(thread->stop_sem);
  mailsem_free(thread->start_sem);
  carray_free(thread->op_done_list);
  carray_free(thread->op_list);
  pthread_mutex_destroy(&thread->lock);
  free(thread);
}

struct etpan_thread_op * etpan_thread_op_new(void)
{
  struct etpan_thread_op * op;
  int r;
  
  op = malloc(sizeof(* op));
  if (op == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  op->thread = NULL;
  op->run = NULL;
  op->callback = NULL;
  op->callback_data = NULL;
  op->callback_called = 0;
  op->cancellable = 0;
  op->cancelled = 0;
  op->param = NULL;
  op->result = NULL;
  
  r = pthread_mutex_init(&op->lock, NULL);
  if (r != 0) {
    free(op);
    ETPAN_LOG("failed to create mutex (op)");
    etpan_crash();
  }
  
  return op;
}

void etpan_thread_op_free(struct etpan_thread_op * op)
{
  pthread_mutex_destroy(&op->lock);
  free(op);
}

static struct etpan_thread *
etpan_thread_manager_create_thread(struct etpan_thread_manager * manager)
{
  struct etpan_thread * thread;
  int r;
  
  thread = etpan_thread_new();
  thread->manager = manager;
  etpan_thread_start(thread);
  
  r = carray_add(manager->thread_pool, thread, NULL);
  if (r < 0) {
    etpan_thread_stop(thread);
    ETPAN_LOG_MEMORY_ERROR;
  }
  
  return thread;
}

static void
etpan_thread_manager_terminate_thread(struct etpan_thread_manager * manager,
    struct etpan_thread * thread)
{
  unsigned int i;
  int r;
  
  for(i = 0 ; i < carray_count(manager->thread_pool) ; i ++) {
    if (carray_get(manager->thread_pool, i) == thread) {
      carray_delete(manager->thread_pool, i);
      break;
    }
  }
  
  if (!etpan_thread_is_bound(thread))
    manager->unbound_count --;
  
  r = carray_add(manager->thread_pending, thread, NULL);
  if (r < 0) {
    ETPAN_LOG_MEMORY_ERROR;
  }
  
  etpan_thread_stop(thread);
}

static void manager_notify(struct etpan_thread_manager * manager)
{
  char ch;
  ssize_t r;
  
  ch = 1;
  r = write(manager->notify_fds[1], &ch, 1);
  if (r != 1) {
    ETPAN_LOG("could not notify thread manager");
    etpan_crash();
  }
}

static void manager_ack(struct etpan_thread_manager * manager)
{
  char ch;
  ssize_t r;
  
  r = read(manager->notify_fds[0], &ch, 1);
  if (r != 1) {
    ETPAN_LOG("could not acknowledge");
    etpan_crash();
  }
}

static void thread_lock(struct etpan_thread * thread)
{
  pthread_mutex_lock(&thread->lock);
}

static void thread_unlock(struct etpan_thread * thread)
{
  pthread_mutex_unlock(&thread->lock);
}

static void thread_notify(struct etpan_thread * thread)
{
  manager_notify(thread->manager);
}

static void * thread_run(void * data)
{
  struct etpan_thread * thread;
  int r;
  
  thread = data;
  
  mailsem_up(thread->start_sem);
  
  while (1) {
    int do_quit;
    struct etpan_thread_op * op;
    
    mailsem_down(thread->op_sem);
    
    do_quit = 0;
    op = NULL;
    thread_lock(thread);
    if (carray_count(thread->op_list) > 0) {
      op = carray_get(thread->op_list, 0);
      carray_delete_slow(thread->op_list, 0);
    }
    else {
      do_quit = 1;
    }
    thread_unlock(thread);
    
    if (do_quit) {
      break;
    }
    
    if (!etpan_thread_op_cancelled(op)) {
      if (op->run != NULL)
        op->run(op);
    }
    
    thread_lock(thread);
    r = carray_add(thread->op_done_list, op, NULL);
    if (r < 0) {
      ETPAN_LOG_MEMORY_ERROR;
    }
    thread_unlock(thread);
    
    thread_notify(thread);
  }
  
  thread_lock(thread);
  thread->terminate_state = TERMINATE_STATE_DONE;
  thread_unlock(thread);
  
  thread_notify(thread);
  
  mailsem_up(thread->stop_sem);
  
  return NULL;
}

void etpan_thread_start(struct etpan_thread * thread)
{
  int r;
  
  r = pthread_create(&thread->th_id, NULL, thread_run, thread);
  if (r != 0) {
    ETPAN_LOG("could not create thread");
    etpan_crash();
  }
  
  mailsem_down(thread->start_sem);
}

void etpan_thread_stop(struct etpan_thread * thread)
{
  if (etpan_thread_is_bound(thread)) {
    ETPAN_LOG("is bound %p %i", thread, etpan_thread_is_bound(thread));
    etpan_log_stack();
  }
  
  thread_lock(thread);
  thread->terminate_state = TERMINATE_STATE_REQUESTED;
  thread_unlock(thread);
  
  mailsem_up(thread->op_sem);
  
  /* this thread will be joined in the manager loop */
}

int etpan_thread_is_stopped(struct etpan_thread * thread)
{
  int stopped;
  
  thread_lock(thread);
  stopped = (thread->terminate_state == TERMINATE_STATE_DONE);
  thread_unlock(thread);
  
  return stopped;
}

void etpan_thread_join(struct etpan_thread * thread)
{
  mailsem_down(thread->stop_sem);
  pthread_join(thread->th_id, NULL);
}

struct etpan_thread *
etpan_thread_manager_get_thread(struct etpan_thread_manager * manager)
{
  struct etpan_thread * chosen_thread;
  unsigned int chosen_thread_load;
  unsigned int i;
  struct etpan_thread * thread;
  
  /* chose a thread */
  
  chosen_thread = NULL;
  chosen_thread_load = 0;
  
  for(i = 0 ; i < carray_count(manager->thread_pool) ; i ++) {
    thread = carray_get(manager->thread_pool, i);
    if (etpan_thread_is_bound(thread))
      continue;
    
    if (chosen_thread == NULL) {
      chosen_thread = thread;
      chosen_thread_load = etpan_thread_get_load(thread);
      
      if (chosen_thread_load == 0)
        break;
    }
    else {
      unsigned int load;
      
      load = etpan_thread_get_load(thread);
      
      if (load < chosen_thread_load) {
        chosen_thread = thread;
        chosen_thread_load = load;
      }
    }
  }
  
  if (chosen_thread != NULL) {
    if (manager->can_create_thread && (chosen_thread_load != 0)) {
      chosen_thread = NULL;
    }
  }
  
  /* choice done */
  
  if (chosen_thread != NULL)
    return chosen_thread;
  
  thread = etpan_thread_manager_create_thread(manager);
  manager->unbound_count ++;
  if (manager->unbound_count >= POOL_UNBOUND_MAX)
    manager->can_create_thread = 0;
  
  return thread;
}

unsigned int etpan_thread_get_load(struct etpan_thread * thread)
{
  unsigned int load;
  
  thread_lock(thread);
  load = carray_count(thread->op_list);
  thread_unlock(thread);
  
  return load;
}

void etpan_thread_bind(struct etpan_thread * thread)
{
  thread->bound_count ++;
  thread->manager->unbound_count --;
}

void etpan_thread_unbind(struct etpan_thread * thread)
{
  thread->manager->unbound_count ++;
  thread->bound_count --;
}

int etpan_thread_is_bound(struct etpan_thread * thread)
{
  return (thread->bound_count != 0);
}

void etpan_thread_op_schedule(struct etpan_thread * thread,
    struct etpan_thread_op * op)
{
  int r;
  
  if (thread->terminate_state != TERMINATE_STATE_NONE) {
    ETPAN_LOG("thread already terminated");
    etpan_crash();
  }
  
  thread_lock(thread);
  r = carray_add(thread->op_list, op, NULL);
  thread_unlock(thread);
  
  if (r < 0)
    ETPAN_LOG_MEMORY_ERROR;
  
  op->thread = thread;
  mailsem_up(thread->op_sem);
}

void etpan_thread_op_lock(struct etpan_thread_op * op)
{
  pthread_mutex_lock(&op->lock);
}

void etpan_thread_op_unlock(struct etpan_thread_op * op)
{
  pthread_mutex_unlock(&op->lock);
}

int etpan_thread_op_cancelled(struct etpan_thread_op * op)
{
  int cancelled;
  
  cancelled = 0;
  etpan_thread_op_lock(op);
  if (op->cancellable)
    cancelled = op->cancelled;
  etpan_thread_op_unlock(op);
  
  return cancelled;
}

void etpan_thread_op_cancel(struct etpan_thread_op * op)
{ 
  etpan_thread_op_lock(op);
  if (op->cancelled) {
    ETPAN_LOG("cancelled twice");
  }
  op->cancelled = 1;
  if ((op->callback != NULL) && (!op->callback_called)) {
    op->callback(op->cancelled, op->result, op->callback_data);
    op->callback_called = 1;
  }
  etpan_thread_op_unlock(op);
}

void etpan_thread_manager_op_schedule(struct etpan_thread_manager * manager,
    struct etpan_thread_op * op)
{
  struct etpan_thread * thread;
  
  thread = etpan_thread_manager_get_thread(manager);
  etpan_thread_op_schedule(thread, op);
}

int etpan_thread_manager_get_fd(struct etpan_thread_manager * manager)
{
  return manager->notify_fds[0];
}

static void loop_thread_list(carray * op_to_notify,
    carray * thread_list)
{
  unsigned int i;
  int r;
  
  for(i = 0 ; i < carray_count(thread_list) ; i ++) {
    struct etpan_thread * thread;
    unsigned int j;
    
    thread = carray_get(thread_list, i);
    
    thread_lock(thread);
    
    for(j = 0 ; j < carray_count(thread->op_done_list) ; j ++) {
      struct etpan_thread_op * op;
      
      op = carray_get(thread->op_done_list, j);
      r = carray_add(op_to_notify, op, NULL);
      if (r < 0) {
        ETPAN_LOG_MEMORY_ERROR;
      }
    }
    carray_set_size(thread->op_done_list, 0);
    
    thread_unlock(thread);
  }
}

static void main_thread_run(struct etpan_thread_manager * manager);

void etpan_thread_manager_loop(struct etpan_thread_manager * manager)
{
  carray * op_to_notify;
  unsigned int i;
  
  manager_ack(manager);
  
  op_to_notify = carray_new(OP_INIT_SIZE);
  
  loop_thread_list(op_to_notify, manager->thread_pool);
  loop_thread_list(op_to_notify, manager->thread_pending);
  
  for(i = 0 ; i < carray_count(op_to_notify) ; i ++) {
    struct etpan_thread_op * op;
    int cancelled;
    
    op = carray_get(op_to_notify, i);
    
    cancelled = etpan_thread_op_cancelled(op);
    
    etpan_thread_op_lock(op);
    
    if (!op->callback_called) {
      if (op->callback != NULL)
        op->callback(op->cancelled, op->result, op->callback_data);
    }
    
    etpan_thread_op_unlock(op);
    
    if (op->cleanup != NULL)
      op->cleanup(op);
    
    etpan_thread_op_free(op);
  }
  
  carray_free(op_to_notify);
  
  i = 0;
  while (i < carray_count(manager->thread_pending)) {
    struct etpan_thread * thread;
    
    thread = carray_get(manager->thread_pending, i);
    
    if (etpan_thread_is_stopped(thread)) {
      etpan_thread_join(thread);
      
      etpan_thread_free(thread);
      
      carray_delete_slow(manager->thread_pending, i);
    }
    else {
      i ++;
    }
  }
  
  main_thread_run(manager);
}

void etpan_thread_manager_start(struct etpan_thread_manager * manager)
{
  (void) manager;
  /* do nothing */
}

void etpan_thread_manager_stop(struct etpan_thread_manager * manager)
{
  while (carray_count(manager->thread_pool) > 0) {
    struct etpan_thread * thread;
    
    thread = carray_get(manager->thread_pool, 0);
    etpan_thread_manager_terminate_thread(manager, thread);
  }
}

int etpan_thread_manager_is_stopped(struct etpan_thread_manager * manager)
{
  return ((carray_count(manager->thread_pending) == 0) && 
      (carray_count(manager->thread_pool) == 0));
}

void etpan_thread_manager_join(struct etpan_thread_manager * manager)
{
  while (!etpan_thread_manager_is_stopped(manager)) {
    etpan_thread_manager_loop(manager);
  }
}

struct main_thread_slot {
  void (* f)(void *);
  void * data;
  struct mailsem * sem;
  int wait;
};

static void main_thread_run(struct etpan_thread_manager * manager)
{
#if 0
  unsigned int i;
  
  pthread_mutex_lock(&manager->main_thread_lock);
  for(i = 0 ; i < carray_count(manager->main_thread_list) ; i ++) {
    struct main_thread_slot * elt;
    
    elt = carray_get(manager->main_thread_list, i);
    elt->f(elt->data);
    
    if (elt->wait) {
      mailsem_up(elt->sem);
    }
    else {
      free(elt);
    }
  }
  carray_set_size(manager->main_thread_list, 0);
  pthread_mutex_unlock(&manager->main_thread_lock);
#endif
  while (1) {
    struct main_thread_slot * elt;
    
    pthread_mutex_lock(&manager->main_thread_lock);
    if (carray_count(manager->main_thread_list) > 0) {
      elt = carray_get(manager->main_thread_list, 0);
    }
    else {
      elt = NULL;
    }
    carray_delete_slow(manager->main_thread_list, 0);
    pthread_mutex_unlock(&manager->main_thread_lock);
    if (elt == NULL)
      break;
    
    elt->f(elt->data);
    
    if (elt->wait) {
      mailsem_up(elt->sem);
    }
    else {
      free(elt);
    }
  }
}

void etpan_thread_manager_run_in_main_thread(struct etpan_thread_manager * manager, void (* f)(void *), void * data, int wait)
{
  int r;
  struct main_thread_slot * slot;
  int previous_count;
  
  slot = malloc(sizeof(* slot));
  if (slot == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  slot->f = f;
  slot->data = data;
  if (wait) {
    slot->sem = mailsem_new();
    if (slot->sem == NULL) {
      ETPAN_LOG("failed to create semaphore for main_thread_slot");
      etpan_crash();
    }
  }
  else {
    slot->sem = NULL;
  }
  slot->wait = wait;
  
  pthread_mutex_lock(&manager->main_thread_lock);
  previous_count = carray_count(manager->main_thread_list);
  r = carray_add(manager->main_thread_list, slot, NULL);
  pthread_mutex_unlock(&manager->main_thread_lock);
  
  if (r < 0)
    ETPAN_LOG_MEMORY_ERROR;
  
  /*
  if (slot->wait) {
    manager_notify(manager);
  }
  */
  if (previous_count == 0) {
    manager_notify(manager);
  }
  
  if (slot->wait) {
    mailsem_down(slot->sem);
    mailsem_free(slot->sem);
    free(slot);
  }
}
