#ifndef ETPAN_STORAGE_POP_PRIVATE_H

#define ETPAN_STORAGE_POP_PRIVATE_H

struct mailstorage *
etpan_storage_pop_get_ep_storage(struct etpan_storage * storage);

#endif
