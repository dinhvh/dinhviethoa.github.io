#ifndef ETPAN_FOLDER_POP_H

#define ETPAN_FOLDER_POP_H

#include "etpan-folder-types.h"

struct etpan_folder * etpan_folder_pop_new(void);

#endif
