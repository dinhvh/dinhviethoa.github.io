#ifndef ETPAN_BOOKMARK_CONFIG_H

#define ETPAN_BOOKMARK_CONFIG_H

#include "etpan-bookmark-types.h"
#include "etpan-error-types.h"

struct etpan_error *
etpan_bookmark_config_read(struct etpan_bookmark_manager * manager,
    char * filename) WARN_UNUSED_RESULT;

struct etpan_error * etpan_bookmark_config_read_default(void) WARN_UNUSED_RESULT;

/* XXX - need save */

#endif
