#ifndef ETPAN_URI_TYPES_H

#define ETPAN_URI_TYPES_H

struct etpan_uri {
  char * scheme;
  char * opaque;
  char * authority;
  char * server;
  char * user;
  int port;
  char * path;
  char * query;
  char * fragment;
};

#endif
