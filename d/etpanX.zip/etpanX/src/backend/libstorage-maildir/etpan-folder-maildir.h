#ifndef ETPAN_FOLDER_MAILDIR_H

#define ETPAN_FOLDER_MAILDIR_H

struct etpan_folder * etpan_folder_maildir_new(void);

#endif
