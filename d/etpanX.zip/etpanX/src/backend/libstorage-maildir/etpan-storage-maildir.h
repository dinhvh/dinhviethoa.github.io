#ifndef ETPAN_STORAGE_MAILDIR_H

#define ETPAN_STORAGE_MAILDIR_H

#include "etpan-storage-types.h"

struct etpan_storage * etpan_storage_maildir_new(void);

void etpan_storage_maildir_set_path(struct etpan_storage * storage, char * path);

char * etpan_storage_maildir_get_path(struct etpan_storage * storage);

#endif
