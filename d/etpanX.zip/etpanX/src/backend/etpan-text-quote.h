#ifndef ETPAN_QUOTE_H

#define ETPAN_QUOTE_H

#include <sys/types.h>

void etpan_quote_text(char * input, size_t input_size,
    char ** p_output, size_t * p_output_size);

#endif
