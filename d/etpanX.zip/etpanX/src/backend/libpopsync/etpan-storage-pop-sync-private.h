#ifndef ETPAN_STORAGE_POP_SYNC_PRIVATE_H

#define ETPAN_STORAGE_POP_SYNC_PRIVATE_H

#include "etpan-pop-sync-types.h"
#include "etpan-storage.h"

struct etpan_pop_sync *
etpan_storage_pop_sync_get_pop_sync(struct etpan_storage * storage);

#endif
