#ifndef ETPAN_MESSAGE_COLOR_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_message_color {
  chash * msgid_hash;
};

#endif
