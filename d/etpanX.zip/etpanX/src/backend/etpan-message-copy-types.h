#ifndef ETPAN_MESSAGE_COPY_TYPES_H

#define ETPAN_MESSAGE_COPY_TYPES_H

#include "etpan-folder-types.h"
#include "etpan-message-fetcher-types.h"
#include "etpan-error-types.h"

#define ETPAN_MESSAGE_COPY_FINISHED_SIGNAL \
  "org.etpan.message-copy.finished"

struct etpan_message_copy {
  int ref_count;
  struct etpan_folder * folder;
  carray * msgtab;
  carray * msgid_list;
  unsigned int next_msg;
  int delete;
  int state;
  struct etpan_message_fetcher * fetcher;
  struct etpan_thread_op * op;
  struct etpan_error * error;
  carray * error_list;
  chash * msg_copied;
  chash * msg_deleted;
  chash * pending_for_copy;
  chash * pending_for_deletion;
};

#endif
