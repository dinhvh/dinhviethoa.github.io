#ifndef ETPAN_SENDER_SENT_FOLDER_H

#define ETPAN_SENDER_SENT_FOLDER_H

#include "etpan-sender-types.h"
#include "etpan-storage-types.h"

struct etpan_sender * etpan_sender_sent_folder_new(void);

void etpan_sender_sent_folder_set_storage(struct etpan_sender * sender,
    struct etpan_storage * storage);

#endif
