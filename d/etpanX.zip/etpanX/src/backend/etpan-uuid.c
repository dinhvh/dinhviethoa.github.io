#include "etpan-uuid.h"

#include <stdlib.h>

#include "etpan-log.h"
#include "uuid.h"

char * etpan_uuid_generate(void)
{
  uuid_t uuid_value;
  char * value;
  
  value = malloc(64);
  if (value == NULL)
    ETPAN_LOG_MEMORY_ERROR;
  
  uuid_generate(uuid_value);
  uuid_unparse(uuid_value, value);
  
  return value;
}
