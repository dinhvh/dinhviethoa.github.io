#ifndef ETPAN_MSG_LIST_VIEW_TYPES_H

#define ETPAN_MSG_LIST_VIEW_TYPES_H

#include <libetpan/libetpan.h>
#include "etpan-message-tree-lep-types.h"
#include "etpan-thread-manager-types.h"

#define ETPAN_MSG_LIST_VIEW_UPDATED_SIGNAL \
    "org.etpan.msg-list-view.updated"

struct etpan_msg_list_view {
  chash * msg_hash;
  
  int schedule_build;
  int building_tree;
  struct etpan_thread_op * op;
  
  struct etpan_message_tree * msg_tree;
  carray * new_messages;
  struct etpan_error * error;
  chash * folders_for_orphans;
  int changed;
};

#endif
