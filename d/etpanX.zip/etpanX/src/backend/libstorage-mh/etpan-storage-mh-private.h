#ifndef ETPAN_STORAGE_MH_PRIVATE_H

#define ETPAN_STORAGE_MH_PRIVATE_H

#include "etpan-storage-types.h"

char * etpan_storage_mh_get_threaded_path(struct etpan_storage *
    storage);

#endif
