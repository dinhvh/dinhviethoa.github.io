#ifndef ETPAN_STORAGE_MH_H

#define ETPAN_STORAGE_MH_H

#include "etpan-storage-types.h"

struct etpan_storage * etpan_storage_mh_new(void);

void etpan_storage_mh_set_path(struct etpan_storage * storage, char * path);

char * etpan_storage_mh_get_path(struct etpan_storage * storage);

void etpan_storage_mh_set_cache_path(struct etpan_storage * storage,
    char * cache_path);

char * etpan_storage_mh_get_cache_path(struct etpan_storage * storage);

void etpan_storage_mh_set_flags_path(struct etpan_storage * storage,
    char * cache_path);

char * etpan_storage_mh_get_flags_path(struct etpan_storage * storage);

#endif
