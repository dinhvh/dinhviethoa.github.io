#ifndef ETPAN_FOLDER_MH_H

#define ETPAN_FOLDER_MH_H

struct etpan_folder * etpan_folder_mh_new(void);

#endif
