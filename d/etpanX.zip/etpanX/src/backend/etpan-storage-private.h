#ifndef ETPAN_STORAGE_PRIVATE_H

#define ETPAN_STORAGE_PRIVATE_H

#include "etpan-storage-types.h"
#include "etpan-folder-types.h"

void etpan_storage_mark_connected_folder(struct etpan_storage * storage,
    struct etpan_folder * folder, int connected);

struct etpan_error * etpan_storage_connect_nt(struct etpan_storage * storage) WARN_UNUSED_RESULT;
void etpan_storage_disconnect_nt(struct etpan_storage * storage);

char * etpan_storage_get_threaded_cache_path(struct etpan_storage *
    storage);

char * etpan_storage_get_threaded_flags_path(struct etpan_storage *
    storage);

#endif
