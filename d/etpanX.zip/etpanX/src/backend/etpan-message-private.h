#ifndef ETPAN_MESSAGE_PRIVATE_H

#define ETPAN_MESSAGE_PRIVATE_H

#include "etpan-message-types.h"
#include "etpan-error-types.h"

void etpan_message_set_clean(struct etpan_message * msg);

int etpan_message_has_dirty_flags(struct etpan_message * msg);

struct etpan_error * etpan_message_check(struct etpan_message * msg,
    struct etpan_message_flags * flags) WARN_UNUSED_RESULT;

#endif
