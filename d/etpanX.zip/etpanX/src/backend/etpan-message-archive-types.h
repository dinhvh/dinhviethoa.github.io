#ifndef ETPAN_MESSAGE_ARCHIVE_TYPES_H

#define ETPAN_MESSAGE_ARCHIVE_TYPES_H

#define ETPAN_MESSAGE_ARCHIVE_FINISHED_SIGNAL \
  "org.etpan.message-archive.finished"

#include <libetpan/libetpan.h>

#include "etpan-message-copy-local-types.h"
#include "etpan-error-types.h"

struct etpan_message_archive {
  int ref_count;
  struct etpan_message_copy_local * msg_copy_local;
  struct etpan_error * error;
};

#endif
