#ifndef ETPAN_MESSAGE_DELETE_H

#define ETPAN_MESSAGE_DELETE_H

#include "etpan-message-delete-types.h"
#include "etpan-error-types.h"

struct etpan_message_delete * etpan_message_delete_new(void);

void etpan_message_delete_ref(struct etpan_message_delete * msg_delete);
void etpan_message_delete_unref(struct etpan_message_delete * msg_delete);

void etpan_message_delete_set_msglist(struct etpan_message_delete * msg_delete,
    chash * msglist);

void etpan_message_delete_setup(struct etpan_message_delete * msg_delete);

void etpan_message_delete_run(struct etpan_message_delete * msg_delete);
void etpan_message_delete_cancel(struct etpan_message_delete * msg_delete);

struct etpan_error *
etpan_message_delete_get_error(struct etpan_message_delete * msg_delete);

chash * etpan_message_delete_get_pending_for_deletion(struct etpan_message_delete * msg_delete);

#endif
