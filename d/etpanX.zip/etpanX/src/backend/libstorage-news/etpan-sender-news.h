#ifndef ETPAN_SENDER_NEWS_H

#define ETPAN_SENDER_NEWS_H

#include "etpan-sender-types.h"
#include "etpan-storage-types.h"

struct etpan_sender * etpan_sender_news_new(void);

void etpan_sender_news_set_storage(struct etpan_sender * sender,
    struct etpan_storage * storage);

#endif
