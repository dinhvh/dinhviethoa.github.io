#ifndef ETPAN_STORAGE_NEWS_PRIVATE_H

#define ETPAN_STORAGE_NEWS_PRIVATE_H

#include <libetpan/libetpan.h>
#include "etpan-storage-types.h"

struct mailstorage *
etpan_storage_news_get_ep_storage(struct etpan_storage * storage);

#endif
 
