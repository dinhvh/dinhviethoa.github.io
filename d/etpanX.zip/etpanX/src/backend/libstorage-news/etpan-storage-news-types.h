#ifndef ETPAN_STORAGE_NEWS_TYPES_H

#define ETPAN_STORAGE_NEWS_TYPES_H

struct etpan_storage_news_append_msg_result {
  struct etpan_error * error;
};

#endif
