#ifndef ETPAN_FOLDER_NEWS_H

#define ETPAN_FOLDER_NEWS_H

struct etpan_folder * etpan_folder_news_new(void);

#endif
