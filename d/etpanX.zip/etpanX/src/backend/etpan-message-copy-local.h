#ifndef ETPAN_MESSAGE_COPY_LOCAL_H

#define ETPAN_MESSAGE_COPY_LOCAL_H

#include "etpan-message-copy-local-types.h"
#include "etpan-error-types.h"

struct etpan_message_copy_local * etpan_message_copy_local_new(void);

void etpan_message_copy_local_set_delete(struct etpan_message_copy_local * msg_copy_local, int delete);
void etpan_message_copy_local_set_folder_name(struct etpan_message_copy_local * msg_copy_local, char * folder_name);

void etpan_message_copy_local_ref(struct etpan_message_copy_local * msg_copy_local);
void etpan_message_copy_local_unref(struct etpan_message_copy_local * msg_copy_local);

void etpan_message_copy_local_set_msglist(struct etpan_message_copy_local * msg_copy_local,
    chash * msglist);

void etpan_message_copy_local_setup(struct etpan_message_copy_local * msg_copy_local);

void etpan_message_copy_local_run(struct etpan_message_copy_local * msg_copy_local);
void etpan_message_copy_local_cancel(struct etpan_message_copy_local * msg_copy_local);

struct etpan_error *
etpan_message_copy_local_get_error(struct etpan_message_copy_local * msg_copy_local);

chash * etpan_message_copy_local_get_pending_for_deletion(struct etpan_message_copy_local * msg_copy_local);

#endif
