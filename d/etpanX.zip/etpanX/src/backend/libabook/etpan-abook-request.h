#ifndef ETPAN_ABOOK_REQUEST_H

#define ETPAN_ABOOK_REQUEST_H

#include "etpan-abook-request-types.h"

struct etpan_abook_request *
etpan_abook_request_new(struct etpan_abook_manager * manager);

void etpan_abook_request_set_flags(struct etpan_abook_request * request,
    int flags);
int etpan_abook_request_get_flags(struct etpan_abook_request * request);

void etpan_abook_request_lookup(struct etpan_abook_request * request,
    char * key);

struct etpan_error *
etpan_abook_request_get_error(struct etpan_abook_request * request);

void etpan_abook_request_cancel(struct etpan_abook_request * request);

carray * etpan_abook_request_get_result(struct etpan_abook_request * request);

void etpan_abook_request_free(struct etpan_abook_request * request);

#endif
