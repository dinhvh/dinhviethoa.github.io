#ifndef ETPAN_ABOOK_MANAGER_TYPES_H

#define ETPAN_ABOOK_MANAGER_TYPES_H

#include <libetpan/libetpan.h>

#define ETPAN_ABOOK_MANAGER_MODIFICATION_SIGNAL \
  "org.etpan.abook-manager.modification"

struct etpan_abook_manager {
  chash * abook_hash;
  carray * ordered_list;

  int stop_remaining;
  void * stop_cb_data;
  void (* stop_callback)(void *);
};

#endif
