#ifndef ETPAN_ABOOK_LDAP_H

#define ETPAN_ABOOK_LDAP_H

#include "etpan-abook-types.h"

struct etpan_abook * etpan_abook_ldap_new(void);

void etpan_abook_ldap_set_hostname(struct etpan_abook * abook, char * hostname);
char * etpan_abook_ldap_get_hostname(struct etpan_abook * abook);

void etpan_abook_ldap_set_username(struct etpan_abook * abook, char * username);
char * etpan_abook_ldap_get_username(struct etpan_abook * abook);

void etpan_abook_ldap_set_password(struct etpan_abook * abook, char * password);
char * etpan_abook_ldap_get_password(struct etpan_abook * abook);

void etpan_abook_ldap_set_base(struct etpan_abook * abook, char * base);
char * etpan_abook_ldap_get_base(struct etpan_abook * abook);

void etpan_abook_ldap_set_port(struct etpan_abook * abook, int port);
int etpan_abook_ldap_get_port(struct etpan_abook * abook);

void etpan_abook_ldap_set_connection_type(struct etpan_abook * abook,
    int connection_type);
int etpan_abook_ldap_get_connection_type(struct etpan_abook * abook);

void etpan_abook_ldap_set_auth_type(struct etpan_abook * abook,
    int connection_type);
int etpan_abook_ldap_get_auth_type(struct etpan_abook * abook);

#endif
