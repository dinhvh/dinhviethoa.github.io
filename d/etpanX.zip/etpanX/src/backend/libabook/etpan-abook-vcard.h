#ifndef ETPAN_ABOOK_VCARD_H

#define ETPAN_ABOOK_VCARD_H

#include "etpan-abook-types.h"

struct etpan_abook * etpan_abook_vcard_new(void);

void etpan_abook_vcard_set_filename(struct etpan_abook * abook, char * filename);
char * etpan_abook_vcard_get_filename(struct etpan_abook * abook);

#endif
