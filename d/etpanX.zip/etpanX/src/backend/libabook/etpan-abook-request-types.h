#ifndef ETPAN_ABOOK_REQUEST_TYPES_H

#define ETPAN_ABOOK_REQUEST_TYPES_H

#include "etpan-abook-manager-types.h"
#include "etpan-error-types.h"

#include <libetpan/libetpan.h>

#define ETPAN_ABOOK_REQUEST_UPDATED_RESULT \
  "org.etpan.abook-request.updated-result"

#define ETPAN_ABOOK_REQUEST_FINISHED \
  "org.etpan.abook-request.finished"

enum {
  ETPAN_ABOOK_REQUEST_FLAGS_DISABLE_NETWORK = 1 << 0,
};

struct etpan_abook_request {
  struct etpan_abook_manager * manager;
  int remaining;
  chash * remaining_op;
  carray * result;
  char * key;
  int cancelled;
  int flags;
  struct etpan_error * error;
  carray * error_list;
};

#endif
