#ifndef ETPAN_UUID_H

#define ETPAN_UUID_H

char * etpan_uuid_generate(void);

#endif
