#ifndef ETPAN_FOLDER_TREE_TYPES_H

#define ETPAN_FOLDER_TREE_TYPES_H

#include "etpan-folder-types.h"

struct etpan_folder_tree {
  char * ui_path;
  struct etpan_folder * folder;
  struct etpan_folder_tree * parent;
  carray * children;
};

#endif
