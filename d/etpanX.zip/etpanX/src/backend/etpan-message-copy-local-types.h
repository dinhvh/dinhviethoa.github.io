#ifndef ETPAN_MESSAGE_COPY_LOCAL_TYPES_H

#define ETPAN_MESSAGE_COPY_LOCAL_TYPES_H

#define ETPAN_MESSAGE_COPY_LOCAL_FINISHED_SIGNAL \
  "org.etpan.message-copy-local.finished"

#include <libetpan/libetpan.h>

struct etpan_message_copy_local {
  int ref_count;
  char * folder_name;
  int delete;
  carray * msg_copy_list;
  carray * folder_create_list;
  carray * msgtab;
  chash * storage_hash;
  unsigned int done_count;
  carray * error_list;
  struct etpan_error * error;
  chash * pending_for_deletion;
};

#endif
