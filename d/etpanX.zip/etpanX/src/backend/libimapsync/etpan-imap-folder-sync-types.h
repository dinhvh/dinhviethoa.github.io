#ifndef ETPAN_IMAP_FOLDER_SYNC_TYPES_H

#define ETPAN_IMAP_FOLDER_SYNC_TYPES_H

#include "etpan-sqldb-types.h"
#include "etpan-imap-sync-types.h"

#define ETPAN_IMAP_FOLDER_SYNC_OP_ENDED_SIGNAL \
 "org.etpan.imap-sync.folder-op-ended"

#define ETPAN_IMAP_FOLDER_SYNC_CONTENT_UPDATED_SIGNAL \
 "org.etpan.imap-sync.folder-content-updated"

enum {
    ETPAN_IMAP_PART_TYPE_MAIN,
    ETPAN_IMAP_PART_TYPE_HEADER,
    ETPAN_IMAP_PART_TYPE_MIME,
};

struct etpan_imap_folder_sync {
  struct etpan_imap_sync * imap_sync;
  char * location;
#if 0
  struct mailfolder * ep_folder;
#endif
  struct etpan_sqldb * header_db;
  struct etpan_sqldb * body_db;
  pthread_mutex_t header_lock;
  pthread_mutex_t body_lock;
  struct etpan_sqldb * append_db;
  carray * append_queue;
  unsigned int current_append_index;
  int append_has_items;
  pthread_mutex_t append_lock;
  
  int connected;
  int noinferiors;
  int separator;
  
  int state;
  
  uint32_t * uid_list;
  unsigned uid_count;
  uint32_t env_lastuid;
  double last_flags_sync_date;
  unsigned int msg_count;
  unsigned int unseen_count;
  unsigned int recent_count;
  carray * fetch_groups;
  carray * flag_groups;
  uint32_t * body_uid_list;
  unsigned int body_uid_count;
  unsigned int current_fetch_group_index;
  unsigned int current_flag_group_index;
  unsigned int current_body_index;
  
  double last_sync_date;
  struct etpan_thread_op * op;
  
  int opened;
  chash * pending_flags;
  pthread_mutex_t pending_flags_lock;
  int check_requested;
  pthread_mutex_t check_requested_lock;
  
  int skip_flags;
  chash * flags_updated_hash;
  
  int fetching_msg;
  uint32_t fetching_msg_uid;
  
  struct etpan_error * error;
  
  pthread_mutex_t ref_lock;
  int ref_count;
};

#endif
