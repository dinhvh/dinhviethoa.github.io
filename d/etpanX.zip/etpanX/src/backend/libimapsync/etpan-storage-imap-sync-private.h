#ifndef ETPAN_STORAGE_IMAP_SYNC_PRIVATE_H

#define ETPAN_STORAGE_IMAP_SYNC_PRIVATE_H

#include "etpan-storage-types.h"
#include "etpan-imap-sync-types.h"

struct etpan_imap_sync *
etpan_storage_imap_sync_get_imap_sync(struct etpan_storage * storage);

#endif
