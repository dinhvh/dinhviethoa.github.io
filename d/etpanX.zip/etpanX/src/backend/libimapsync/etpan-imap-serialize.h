#ifndef ETPAN_IMAP_SERIALIZE_H

#define ETPAN_IMAP_SERIALIZE_H

#include <libetpan/libetpan.h>

struct etpan_serialize_data * etpan_imap_serialize_encode_body(struct mailimap_body * body);
struct mailimap_body * etpan_imap_serialize_decode_body(struct etpan_serialize_data * hash);

struct etpan_serialize_data * etpan_imap_serialize_encode_envelope(struct mailimap_envelope * envelope);
struct mailimap_envelope * etpan_imap_serialize_decode_envelope(struct etpan_serialize_data * hash);

void etpan_imap_body_serialize(struct mailimap_body * body,
    void ** p_data, size_t * p_length);

struct mailimap_body *
etpan_imap_body_unserialize(void * data, size_t length);

void etpan_imap_envelope_serialize(struct mailimap_envelope * env,
    void ** p_data, size_t * p_length);

struct mailimap_envelope *
etpan_imap_envelope_unserialize(void * data, size_t length);

#endif
