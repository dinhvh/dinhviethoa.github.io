#ifndef ETPAN_STORAGE_IMAP_SYNC_H

#define ETPAN_STORAGE_IMAP_SYNC_H

#include "etpan-storage-types.h"
#include "etpan-connection-types.h"
#include "etpan-folder-types.h"

struct etpan_storage * etpan_storage_imap_sync_new(void);

void etpan_storage_imap_sync_set_hostname(struct etpan_storage * storage,
    char * hostname);

char * etpan_storage_imap_sync_get_hostname(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_port(struct etpan_storage * storage, int port);
int etpan_storage_imap_sync_get_port(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_connection_type(struct etpan_storage * storage,
    int connection_type);
int etpan_storage_imap_sync_get_connection_type(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_auth_type(struct etpan_storage * storage,
    int auth_type);
int etpan_storage_imap_sync_get_auth_type(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_username(struct etpan_storage * storage,
    char * username);
char * etpan_storage_imap_sync_get_username(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_password(struct etpan_storage * storage,
    char * password);
char * etpan_storage_imap_sync_get_password(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_base_location(struct etpan_storage * storage,
    char * base_location);
char * etpan_storage_imap_sync_get_base_location(struct etpan_storage * storage);

void etpan_storage_imap_sync_set_command(struct etpan_storage * storage,
    char * command);
char * etpan_storage_imap_sync_get_command(struct etpan_storage * storage);

#endif
