#ifndef ETPAN_PART_IMAP_SYNC_H

#define ETPAN_PART_IMAP_SYNC_H

#include "etpan-part.h"
#include <libetpan/libetpan.h>

struct etpan_part * etpan_part_imap_sync_new(void);

void etpan_part_imap_sync_set_body(struct etpan_part * part,
    struct mailimap_body * body);

struct mailimap_body * etpan_part_imap_sync_get_body(struct etpan_part * part);

void etpan_part_imap_sync_set_section(struct etpan_part * part,
    char * section);

#endif
