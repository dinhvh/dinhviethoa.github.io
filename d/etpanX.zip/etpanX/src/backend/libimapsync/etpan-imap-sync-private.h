#ifndef ETPAN_IMAP_SYNC_PRIVATE_H

#define ETPAN_IMAP_SYNC_PRIVATE_H

#include "etpan-imap-sync-types.h"

#include <libetpan/libetpan.h>

#include "etpan-storage-types.h"

struct mailstorage * etpan_imap_sync_get_storage(struct etpan_imap_sync * imap_sync);

void etpan_imap_sync_fetch_folder_list(struct etpan_storage * storage,
    struct etpan_imap_sync * imap_sync,
    chash * folder_list);

void etpan_imap_sync_disconnect_nt(struct etpan_imap_sync * imap_sync);

struct etpan_storage * etpan_imap_sync_get_thread_storage(struct etpan_imap_sync * imap_sync);

#endif
