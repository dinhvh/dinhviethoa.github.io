#ifndef ETPAN_MESSAGE_IMAP_SYNC_PRIVATE_H

#define ETPAN_MESSAGE_IMAP_SYNC_PRIVATE_H

#include "etpan-error-types.h"
#include "etpan-message-types.h"

struct etpan_error *
etpan_message_imap_sync_get_part(struct etpan_message * msg,
    char * section, int part_type,
    void ** p_data, size_t * p_length);

#endif
