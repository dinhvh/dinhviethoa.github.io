#ifndef ETPAN_FOLDER_IMAP_SYNC_H

#define ETPAN_FOLDER_IMAP_SYNC_H

#include "etpan-folder-types.h"
#include "etpan-imap-folder-sync-types.h"

struct etpan_folder * etpan_folder_imap_sync_new(void);

void etpan_folder_imap_sync_set_engine(struct etpan_folder * folder,
    struct etpan_imap_folder_sync * sync);

#endif
