#ifndef ETPAN_MESSAGE_IMAP_SYNC_H

#define ETPAN_MESSAGE_IMAP_SYNC_H

struct etpan_message * etpan_message_imap_sync_new(void);

void etpan_message_imap_sync_set_uid(struct etpan_message * msg, char * uid);

char * etpan_message_imap_sync_get_uid(struct etpan_message * msg);

#endif
