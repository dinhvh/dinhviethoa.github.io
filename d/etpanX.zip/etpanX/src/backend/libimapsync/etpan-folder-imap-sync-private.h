#ifndef ETPAN_FOLDER_IMAP_SYNC_PRIVATE_H

#define ETPAN_FOLDER_IMAP_SYNC_PRIVATE_H

#include "etpan-message-types.h"

void etpan_folder_imap_sync_check_msg(struct etpan_folder * folder,
    struct etpan_message * msg,
    struct etpan_message_flags * flags);

struct etpan_error *
etpan_folder_imap_sync_get_body(struct etpan_folder * folder,
    char * uid, struct mailimap_body ** result);

struct etpan_error *
etpan_folder_imap_sync_get_part(struct etpan_folder * folder,
    char * uid, char * section, int part_type,
    void ** p_data, size_t * p_length);

struct etpan_imap_folder_sync *
etpan_folder_imap_sync_get_folder_sync(struct etpan_folder * folder);

void etpan_folder_imap_sync_set_folder_sync(struct etpan_folder * folder,
    struct etpan_imap_folder_sync * folder_sync);

#endif
