#ifndef ETPAN_GLOBAL_CONFIG_TYPES_H

#define ETPAN_GLOBAL_CONFIG_TYPES_H

struct etpan_global_config {
    char * attachment_folder;
};

#endif
