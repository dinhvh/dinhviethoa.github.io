#ifndef ETPAN_PROGRESS_TYPES_H

#define ETPAN_PROGRESS_TYPES_H

#include <gtk/gtk.h>

struct etpan_progress {
  int animating;
  guint animation_id;
  
  GtkWidget * image;
  int current;
  GdkPixbuf ** progress_anim;
};

#endif
