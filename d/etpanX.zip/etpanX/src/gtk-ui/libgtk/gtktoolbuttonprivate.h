#ifndef GTKTOOLBUTTONPRIVATE_H

#define GTKTOOLBUTTONPRIVATE_H

struct _GtkToolButtonPrivate
{
  GtkWidget *button;

  gchar *stock_id;
  gchar *icon_name;
  gchar *label_text;
  GtkWidget *label_widget;
  GtkWidget *icon_widget;
  
  guint use_underline : 1;
};

#endif
