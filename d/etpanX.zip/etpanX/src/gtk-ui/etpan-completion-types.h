#ifndef ETPAN_COMPLETION_TYPES_H

#define ETPAN_COMPLETION_TYPES_H

#include <gtk/gtk.h>

#include "etpan-gtk-tree-model-types.h"

struct etpan_completion {
  GtkWidget * scrolledtext;
  GtkWidget * textview;
  GtkWidget * window;
  GtkWidget * treeview;
  GtkTextBuffer * buffer;
  GtkTreeViewColumn * col_text;
  GtkWidget * scrolledwindow;
  etpan_gtk_tree_model * completion_model;
  struct etpan_gtk_tree_data_source completion_datasource;
  struct etpan_abook_request * abook_request;
  int requesting;
  int visible;
  gulong timer_id;
  int scheduled;
  gulong size_signal_id;
  gulong changed_signal_id;
  gulong window_keypress_signal_id;
  gulong window_button_signal_id;
  gulong entry_keypress_signal_id;
  gulong list_button_signal_id;
  gulong focus_out_signal_id;
};

#endif
