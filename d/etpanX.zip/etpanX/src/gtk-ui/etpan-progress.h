#ifndef ETPAN_PROGRESS_H

#define ETPAN_PROGRESS_H

#include "etpan-progress-types.h"

struct etpan_progress * etpan_progress_new(void);

void etpan_progress_free(struct etpan_progress * progress);

GtkWidget * etpan_progress_get_main_widget(struct etpan_progress * progress);

void etpan_progress_start_animation(struct etpan_progress * progress);
void etpan_progress_stop_animation(struct etpan_progress * progress);

void etpan_progress_setup(struct etpan_progress * progress);
void etpan_progress_unsetup(struct etpan_progress * progress);

#endif
