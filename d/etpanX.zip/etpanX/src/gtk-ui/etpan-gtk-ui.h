#ifndef ETPAN_GTK_UI_H

#define ETPAN_GTK_UI_H

#include <gtk/gtk.h>
#include <glib-object.h>
#include <gdk/gdkkeysyms.h>

#include "etpan-bookmark.h"
#include "etpan-toolbar.h"
#include "etpan-folder-list.h"
#include "etpan-message-list.h"
#include "etpan-message-view.h"
#include "etpan-tabbed-message-list.h"
#include "etpan-status-bar.h"
#include "etpan-main-window.h"
#include "etpan-message-composer-window.h"
#include "etpan-ui-config.h"
#include "etpan-preferences-window.h"
#include "etpan-icon-manager.h"

#include "etpan-gtk-ui-main.h"

#endif
