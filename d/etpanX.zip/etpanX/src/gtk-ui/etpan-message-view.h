#ifndef ETPAN_MESSAGE_VIEW_H

#define ETPAN_MESSAGE_VIEW_H

#include "etpan-message-view-types.h"

struct etpan_message_view * etpan_message_view_new(void);
void etpan_message_view_free(struct etpan_message_view * msg_view);

GtkWidget * etpan_message_view_get_main_widget(struct etpan_message_view *
    msg_view);

void etpan_message_view_set_message(struct etpan_message_view * msg_view,
    struct etpan_message * msg);

void etpan_message_view_set_status_bar(struct etpan_message_view * msg_view,
    struct etpan_status_bar * status_bar);

void etpan_message_view_setup(struct etpan_message_view * msg_view);
void etpan_message_view_unsetup(struct etpan_message_view * msg_view);

void etpan_message_view_set_message_list(struct etpan_message_view * msg_view,
    struct etpan_message_list * msg_list);

void etpan_message_view_scroll_page_down(struct etpan_message_view * msg_view);

void etpan_message_view_set_mode(struct etpan_message_view * msg_view, int mode);
int etpan_message_view_get_mode(struct etpan_message_view * msg_view);

#endif
