#ifndef ETPAN_GTK_UI_MAIN_TYPES_H

#define ETPAN_GTK_UI_MAIN_TYPES_H

#define ETPAN_GTK_UI_MAIN_CLOSE_SIGNAL \
  "org.etpan.gtk-ui-main.close"

#endif
