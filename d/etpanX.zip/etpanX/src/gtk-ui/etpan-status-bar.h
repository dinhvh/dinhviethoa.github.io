#ifndef ETPAN_STATUS_BAR_H

#define ETPAN_STATUS_BAR_H

#include "etpan-status-bar-types.h"

struct etpan_status_bar * etpan_status_bar_new(void);

void etpan_status_bar_free(struct etpan_status_bar * status_bar);

GtkWidget * etpan_status_bar_get_main_widget(struct etpan_status_bar * status_bar);

void etpan_status_bar_start_animation(struct etpan_status_bar * status_bar);
void etpan_status_bar_stop_animation(struct etpan_status_bar * status_bar);

void etpan_status_bar_setup(struct etpan_status_bar * status_bar);
void etpan_status_bar_unsetup(struct etpan_status_bar * status_bar);

#endif
