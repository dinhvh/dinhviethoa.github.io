#ifndef ETPAN_ICON_MANAGER_TYPES_H

#define ETPAN_ICON_MANAGER_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_icon_manager {
  char * path;
  chash * pixbuf_hash;
};

#endif
