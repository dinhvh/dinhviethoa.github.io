#ifndef ETPAN_TABBED_MESSAGE_LIST_TYPES_H

#define ETPAN_TABBED_MESSAGE_LIST_TYPES_H

#include <gtk/gtk.h>
#include <libetpan/libetpan.h>
#include "etpan-folder-list-types.h"
#include "etpan-bookmark-view-types.h"
#include "etpan-status-bar-types.h"
#include "etpan-search-field-types.h"

#define ETPAN_TABBED_MESSAGE_LIST_SELECTIONCHANGED_SIGNAL \
  "org.etpan.tabbed-message-list.selection-changed"

struct etpan_tabbed_message_list {
  GtkWidget * notebook;
  carray * folder_info_list;
  struct etpan_folder_list * folder_list;
  struct etpan_bookmark_view * bookmark_view;
  struct etpan_status_bar * status_bar;
  struct etpan_search_field * search_field;
  int current_tab;
  gulong selected_signal_id;
};

#endif
