#ifndef ETPAN_GTK_WORKAROUND_H

#define ETPAN_GTK_WORKAROUND_H

void gtk_tree_store_update_lock(void);
void gtk_tree_store_update_unlock(void);

#endif
