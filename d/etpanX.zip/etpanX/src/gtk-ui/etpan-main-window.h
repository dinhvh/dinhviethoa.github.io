#ifndef ETPAN_MAIN_WINDOW_H

#define ETPAN_MAIN_WINDOW_H

#include "etpan-main-window-types.h"

struct etpan_main_window * etpan_main_window_new(void);
void etpan_main_window_free(struct etpan_main_window * main_window);

GtkWidget * etpan_main_window_get_main_widget(struct etpan_main_window *
    main_window);

struct etpan_toolbar *
etpan_main_window_get_toolbar(struct etpan_main_window * main_window);
struct etpan_bookmark_view *
etpan_main_window_get_bookmark_view(struct etpan_main_window * main_window);
struct etpan_folder_list *
etpan_main_window_get_folder_list(struct etpan_main_window * main_window);
struct etpan_status_bar *
etpan_main_window_get_status_bar(struct etpan_main_window * main_window);
struct etpan_tabbed_message_list *
etpan_main_window_get_tabbed_message_list(struct etpan_main_window *
    main_window);

void etpan_main_window_setup(struct etpan_main_window * main_window);
void etpan_main_window_unsetup(struct etpan_main_window * main_window);

void etpan_main_window_set_default(struct etpan_main_window * main_window);
struct etpan_main_window * etpan_main_window_get_default(void);

#endif
