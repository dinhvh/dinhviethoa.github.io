#ifndef ETPAN_BOOKMARK_VIEW_TYPES

#define ETPAN_BOOKMARK_VIEW_TYPES

#include <gtk/gtk.h>
#include <libetpan/libetpan.h>

struct etpan_bookmark_view {
  GtkWidget * bookmark;
  carray * button_list;
  struct etpan_message_list * message_list;
};

#endif
