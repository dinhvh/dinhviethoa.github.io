#ifndef ETPAN_PREFERENCES_VIEW_H

#define ETPAN_PREFERENCES_VIEW_H

#include "etpan-preferences-window-types.h"

void etpan_preferences_view_init(struct etpan_preferences_window * preferences);

#endif
