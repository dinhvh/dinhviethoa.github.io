#ifndef ETPAN_PREFERENCES_ACCOUNT_H

#define ETPAN_PREFERENCES_ACCOUNT_H

#include "etpan-preferences-window-types.h"

void etpan_preferences_account_init(struct etpan_preferences_window * preferences);

#endif
