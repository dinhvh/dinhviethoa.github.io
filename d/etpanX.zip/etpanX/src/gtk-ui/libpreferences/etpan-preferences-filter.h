#ifndef ETPAN_PREFERENCES_FILTER_H

#define ETPAN_PREFERENCES_FILTER_H

#include "etpan-preferences-window-types.h"

void etpan_preferences_filter_init(struct etpan_preferences_window * preferences);

#endif
