#ifndef ETPAN_PREFERENCES_ABOOK_H

#define ETPAN_PREFERENCES_ABOOK_H

#include "etpan-preferences-window.h"

void etpan_preferences_abook_init(struct etpan_preferences_window * preferences);

#endif
