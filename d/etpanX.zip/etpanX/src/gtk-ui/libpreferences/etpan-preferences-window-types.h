#ifndef ETPAN_PREFERENCES_WINDOW_TYPES_H

#define ETPAN_PREFERENCES_WINDOW_TYPES_H

#include <gtk/gtk.h>
#include <libetpan/libetpan.h>

struct etpan_preferences_panel {
  GtkWidget * main_widget;
  chash * widget_list;
  void * data;
  
  void (* open_callback)(struct etpan_preferences_panel * panel);
  int (* should_close_callback)(struct etpan_preferences_panel * panel);
  void (* close_callback)(struct etpan_preferences_panel * panel);
  
  void (* free_data)(struct etpan_preferences_panel * panel);
};

struct etpan_preferences_window {
  GtkWidget * window;
  GtkWidget * notebook;
  GtkWidget * vbox;
  GtkWidget * hbox;
  GtkWidget * close_button;
  carray * panel_data_list;
  gint delete_signal_id;
  gint show_signal_id;
  gint switch_signal_id;
  gint close_clicked_signal_id;
  int current_page;
};

#endif
