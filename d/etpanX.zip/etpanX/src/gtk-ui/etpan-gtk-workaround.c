#include "etpan-gtk-workaround.h"

#include <pthread.h>

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void gtk_tree_store_update_lock(void)
{
  pthread_mutex_lock(&lock);
}

void gtk_tree_store_update_unlock(void)
{
  pthread_mutex_unlock(&lock);
}
