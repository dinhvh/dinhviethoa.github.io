#ifndef ETPAN_COMPLETION_H

#define ETPAN_COMPLETION_H

#include "etpan-completion-types.h"

#include <libetpan/libetpan.h>

struct etpan_completion * etpan_completion_new(void);
void etpan_completion_free(struct etpan_completion * completion);

GtkWidget * etpan_completion_get_main_widget(struct etpan_completion * completion);
GtkWidget * etpan_completion_get_textview(struct etpan_completion * completion);

void etpan_completion_setup(struct etpan_completion * completion);
void etpan_completion_unsetup(struct etpan_completion * completion);

carray * etpan_completion_get_address_list(struct etpan_completion * completion);

#endif
