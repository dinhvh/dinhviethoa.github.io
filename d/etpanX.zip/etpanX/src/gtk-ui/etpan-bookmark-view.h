#ifndef ETPAN_BOOKMARK_VIEW_H

#define ETPAN_BOOKMARK_VIEW_H

#include "etpan-bookmark-view-types.h"
#include "etpan-message-list-types.h"
#include "etpan-backend.h"

struct etpan_bookmark_view * etpan_bookmark_view_new(void);
void etpan_bookmark_view_free(struct etpan_bookmark_view * bookmark_view);

GtkWidget * etpan_bookmark_view_get_main_widget(struct etpan_bookmark_view *
    bookmark_view);

void etpan_bookmark_view_add_item(struct etpan_bookmark_view * bookmark_view,
    struct etpan_bookmark * item);

void etpan_bookmark_view_clear(struct etpan_bookmark_view * bookmark_view);

void etpan_bookmark_view_set_message_list(struct etpan_bookmark_view * bookmark_view, struct etpan_message_list * msg_list);

void etpan_bookmark_view_setup(struct etpan_bookmark_view * bookmark_view);
void etpan_bookmark_view_unsetup(struct etpan_bookmark_view * bookmark_view);

#endif
