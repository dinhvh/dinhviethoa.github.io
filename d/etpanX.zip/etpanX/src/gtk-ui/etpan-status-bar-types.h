#ifndef ETPAN_STATUS_BAR_TYPES_H

#define ETPAN_STATUS_BAR_TYPES_H

#include <gtk/gtk.h>

struct etpan_status_bar {
  int animating;
  guint animation_id;
  
  GtkWidget * status_bar;
  GtkWidget * progress;
  int current_status_bar;
  GdkPixbuf ** status_bar_anim;
};

#endif
