#ifndef ETPAN_CONTEXTUAL_MENU_TYPES

#define ETPAN_CONTEXTUAL_MENU_TYPES

#include <gtk/gtk.h>
#include <libetpan/libetpan.h>

#define ETPAN_CONTEXTUAL_MENU_CLICKED_SIGNAL \
  "org.etpan.contextual-menu.clicked"

struct etpan_contextual_menu {
  GtkWidget * menu;
  carray * item_list;
};

#endif
