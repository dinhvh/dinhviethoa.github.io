#ifndef ETPAN_INPUT_DIALOG_TYPES_H

#define ETPAN_INPUT_DIALOG_TYPES_H

#include <gtk/gtk.h>

#define ETPAN_INPUT_DIALOG_CLOSED_SIGNAL \
  "org.etpan.input-dialog.closed"

enum {
  ETPAN_INPUT_DIALOG_NONE,
  ETPAN_INPUT_DIALOG_DONE,
  ETPAN_INPUT_DIALOG_CANCEL,
};

struct etpan_input_dialog {
  GtkWidget * window;
  GtkWidget * label;
  GtkWidget * entry;
  GtkWidget * done_button;
  GtkWidget * cancel_button;
  gulong done_signal_id;
  gulong cancel_signal_id;
  int result;
};

#endif
