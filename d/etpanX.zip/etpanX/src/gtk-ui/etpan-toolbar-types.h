#ifndef ETPAN_TOOLBAR_TYPES

#define ETPAN_TOOLBAR_TYPES

#include <gtk/gtk.h>
#include <libetpan/libetpan.h>

#define ETPAN_TOOLBAR_BUTTONCLICKED_SIGNAL \
  "org.etpan.toolbar.button-clicked"

struct etpan_toolbar {
  GtkWidget * toolbar;
  carray * button_list;
};

#endif
