#ifndef ETPAN_INPUT_DIALOG_H

#define ETPAN_INPUT_DIALOG_H

#include "etpan-input-dialog-types.h"

struct etpan_input_dialog * etpan_input_dialog_new(void);
void etpan_input_dialog_free(struct etpan_input_dialog * dialog);

void etpan_input_dialog_setup(struct etpan_input_dialog * dialog);
void etpan_input_dialog_unsetup(struct etpan_input_dialog * dialog);

void etpan_input_dialog_show(struct etpan_input_dialog * dialog);
void etpan_input_dialog_hide(struct etpan_input_dialog * dialog);

void etpan_input_dialog_set_title(struct etpan_input_dialog * dialog,
    char * title);
void etpan_input_dialog_set_text(struct etpan_input_dialog * dialog,
    char * text);
void etpan_input_dialog_set_label(struct etpan_input_dialog * dialog,
    char * label);

char * etpan_input_dialog_get_text(struct etpan_input_dialog * dialog);

int etpan_input_dialog_get_result(struct etpan_input_dialog * dialog);

#endif
