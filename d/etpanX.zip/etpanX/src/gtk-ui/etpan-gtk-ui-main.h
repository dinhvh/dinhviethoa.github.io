#ifndef ETPAN_GTK_UI_MAIN_H

#define ETPAN_GTK_UI_MAIN_H

#include "etpan-backend.h"
#include "etpan-gtk-ui-main-types.h"

struct etpan_error * etpan_gtk_ui_init(int * argc, char *** argv) WARN_UNUSED_RESULT;
void etpan_gtk_ui_setup(void);

void etpan_gtk_ui_run(void);

void etpan_gtk_ui_unsetup(void);
void etpan_gtk_ui_stop(void);
void etpan_gtk_ui_quit(void);
void etpan_gtk_ui_done(void);

void etpan_gtk_ui_show_quit_panel(void);
void etpan_gtk_ui_hide_quit_panel(void);

#endif
