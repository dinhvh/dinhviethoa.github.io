#ifndef ETPAN_SEARCH_FIELD_TYPES_H

#define ETPAN_SEARCH_FIELD_TYPES_H

#include <gtk/gtk.h>

#include "etpan-contextual-menu-types.h"
#include "etpan-progress-types.h"

#define ETPAN_SEARCH_FIELD_MODIFIED_SIGNAL \
  "org.etpan.search-field.modified"

struct etpan_search_field {
  GtkWidget * hbox;
  GtkWidget * entry;
  gulong modify_signal_id;
  gulong icon_clicked_signal_id;
  gulong icon_pressed_signal_id;
  gulong motion_signal_id;
  int cancel_find_enabled;
  int search_type;
  struct etpan_contextual_menu * popup_menu;
  int menu_callback_disabled;
  int animation_count;
  struct etpan_progress * progress;
};

#endif
