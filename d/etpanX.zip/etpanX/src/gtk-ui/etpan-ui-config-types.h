#ifndef ETPAN_UI_CONFIG_TYPES_H

#define ETPAN_UI_CONFIG_TYPES_H

#include <libetpan/libetpan.h>

struct etpan_ui_config {
  chash * window_position;
  chash * values;
  char * font_message;
  char * font_list;
  char * font_other;
};

#define ETPAN_UI_CONFIG_FONT_CHANGED_SIGNAL \
 "org.etpan.ui-config.font-changed"

#endif
