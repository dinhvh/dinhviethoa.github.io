#ifndef ETPAN_ABOOK_LOCAL_H

#define ETPAN_ABOOK_LOCAL_H

#include "etpan-abook-driver-types.h"
#include "etpan-cfg-abook-types.h"
#include "etpan-cfg-local-abook-types.h"

struct etpan_abook *
etpan_abook_local_new(struct etpan_global_config * global_config,
    char * filename);

#endif
