#ifndef ETPAN_ABOOK_LDAP_H

#define ETPAN_ABOOK_LDAP_H

#include "etpan-abook-driver-types.h"
#include "etpan-ldap-types.h"
#include "etpan-cfg-global-types.h"

struct etpan_abook *
etpan_abook_ldap_new(struct etpan_global_config * global_config,
    struct etpan_ldap_config * ldap_config);

int etpan_abook_ldap_connect(struct etpan_abook * abook);

#endif
