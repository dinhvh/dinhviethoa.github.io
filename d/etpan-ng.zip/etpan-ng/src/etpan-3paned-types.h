#ifndef ETPAN_3PANED_TYPES_H

#define ETPAN_3PANED_TYPES_H

#include "etpan-subapp-types.h"

struct etpan_3paned {
  struct etpan_subapp * msglist;
  struct etpan_subapp * folderlist;
  struct etpan_subapp * msgview;
};

#endif
