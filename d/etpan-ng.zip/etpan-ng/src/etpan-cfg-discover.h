#ifndef ETPAN_CFG_DISCOVER_H

#define ETPAN_CFG_DISCOVER_H

#include "etpan-folder-discover-types.h"
#include "etpan-cfg-storage-types.h"
#include "etpan-cfg-account-types.h"
#include "etpan-cfg-vfolder-types.h"

int etpan_discover_config_read(char * filename,
    struct etpan_app * app,
    struct etpan_account_config * account_config,
    struct etpan_storage_config * storage_config,
    struct etpan_discovery_manager ** pconfig);

#endif
