#ifndef ETPAN_FOLDER_DISCOVER_TYPES_H

#define ETPAN_FOLDER_DISCOVER_TYPES_H

#include <libetpan/libetpan.h>
#include <pthread.h>

struct etpan_discovery_manager {
  struct etpan_app * app;
  chash * vpath_hash; /* virtualpath => info */
  unsigned int seq;
};

struct etpan_discovery_info {
  int type;
  struct mailstorage * storage;
  char * start_path;
  int changed;
  struct path_list * path_list;
  struct path_list * updated_path_list;
  char * vpath;
  pthread_mutex_t lock;
  struct etpan_account_info * account;
  char * sent_folder;
  char * draft_folder;
};

#endif
