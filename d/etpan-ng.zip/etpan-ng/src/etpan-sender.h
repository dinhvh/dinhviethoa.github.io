#ifndef ETPAN_SENDER_H

#define ETPAN_SENDER_H

int etpan_send_message(struct etpan_sender_item * sender,
    char * message, size_t length);

int etpan_send_message_file(struct etpan_sender_item * sender,
    char * filename);

int etpan_send_mime(struct etpan_sender_item * sender,
    struct mailmime * mime);

#endif
