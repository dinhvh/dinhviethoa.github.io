#ifndef ETPAN_ABOOK_VCARD_H

#define ETPAN_ABOOK_VCARD_H

#include "etpan-abook-driver-types.h"
#include "etpan-cfg-global-types.h"

struct etpan_abook *
etpan_abook_vcard_new(struct etpan_global_config * global_config,
    char * filename);

#endif
