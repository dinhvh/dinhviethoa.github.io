#ifndef ETPAN_3PANED_H

#define ETPAN_3PANED_H

#include "etpan-app-types.h"
#include "etpan-subapp-types.h"

struct etpan_3paned * etpan_3paned_new(struct etpan_app * app);
void etpan_3paned_free(struct etpan_3paned * state);

void etpan_3paned_setup(struct etpan_app * app);

int etpan_3paned(struct etpan_app * app);
struct etpan_subapp * etpan_3paned_get_msglist(struct etpan_app * app);
struct etpan_subapp * etpan_3paned_get_folderlist(struct etpan_app * app);
struct etpan_subapp * etpan_3paned_get_msgview(struct etpan_app * app);
void etpan_3paned_resize(struct etpan_app * app);

void etpan_3paned_check_switch(struct etpan_app * app);

#endif
