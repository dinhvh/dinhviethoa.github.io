#ifndef ETPAN_ABOOK_DRIVER_H

#define ETPAN_ABOOK_DRIVER_H

#include "etpan-abook-driver-types.h"

int etpan_abook_connect(struct etpan_abook * abook);

int etpan_abook_lookup(struct etpan_abook * abook,
    const char * key, carray ** result);

struct etpan_abook_entry * etpan_abook_entry_new(char * name,
    char * addr, char * nick);

void etpan_abook_entry_free(struct etpan_abook_entry * entry);

void etpan_abook_free(struct etpan_abook * abook);

#endif
